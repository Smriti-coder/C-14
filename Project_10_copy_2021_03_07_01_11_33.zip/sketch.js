var path, pathImg 

var boy, boyImg; 

var invisibleleft, invisibleright; 


function preload(){
  //pre-load images
  
  pathImg= loadImage("path.png"); 
  
  boyImg= loadAnimation("Jake1.png", "Jake2.png", "jake3.png", "jake4.PNG", "jake5.png"); 
  
}

function setup(){
  createCanvas(400,400);
  //create sprites here
  path=createSprite(200,200); 
  path.addImage(pathImg); 
  path.velocityY= 4; 
  path.scale= 1.2;  
  
  boy= createSprite(200,350); 
  boy.addAnimation("Boy", boyImg); 
 

  invisibleright= createSprite(400, 0, 100, 800); 
  invisibleright.visible= false; 
  
  invisibleleft= createSprite(0, 0, 50,800); 
  invisibleleft.visible= false; 
  
  
  
  
  
}

function draw() {
  background(0);
  boy.x= mouseX; 
  createEdgeSprites(); 
  
  

  // if(boy.isTouching(invisibleright) && boy.isTouching(invisibleleft)){
     
      boy.collide(invisibleright);
      boy.collide(invisibleleft); 
     
 //  }
  
  if(path.y > 390){
  
  path.y=height/2; 
 
}
   path.velocityY= 4; 
  
   
  
   
    
  
    text(mouseX+","+mouseY, mouseX,mouseY); 
  
  drawSprites(); 
}
